# Development
## taksi_client
```bash
npm install
bower install
cp dist/js/config.dist.js dist/js/config.js
serverUrl: "http://<workspacename>-<username>.c9users.io:8080"
apiUrl: "http://<workspacename>-<username>.c9users.io:8081"
pusherKey: pusherKey
node index.js
```

## taksi_server
```bash
bundle install
rake db:migrate
rails s -b $IP -p 8081
```

# Deployment
For Heroku deployment, you must take into account that the Heroku
client by default only supports one application per repository. To get
around this, we can use the git `subtree` capability like this:
```bash
heroku create
git remote rename heroku server
heroku create
git remote rename heroku klient
git subtree push --prefix taksi_server server master
git subtree push --prefix taksi_client klient master
```

Because now you will not have the default `heroku` remote, for running
Heroku commands you will need to use the `--app` switch like this:

```bash
heroku logs --app <appname>
```

If the deployment has migrations to run, then these commands are helpful:
```bash
# Check the version of the active migration in the database
heroku run --app <app-name> rake db:version
# Run the active migration
heroku run --app <app-name> rake db:migrate
# Restart the app for reloading the schema
heroku restart --app <app-name>
```