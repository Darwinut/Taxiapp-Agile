// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
var app = angular.module('taksi_client', ['ionic', 'ngResource']);

app.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
});
app.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('bookings', {
            url: '/bookings',
            abstract: true,
            templateUrl: 'templates/menu.html',
            controller: 'BookingsCtrl'
        })
        .state('bookings.new', {
            url: '/new',
            views: {
                'menuContent': {
                    templateUrl: 'templates/bookings/new.html'
                }
            }
        })
        .state('taxis', {
            url: "/taxis",
            templateUrl: 'templates/taxi/list.html',
            controller: 'TaxiListCtrl'
        })
        .state('new_taxi', {
            url: '/new_taxi',
            templateUrl: 'templates/taxi/new.html',
            controller: 'CreateTaxiCtrl'
        })
        .state("taxi", {
            url: '/taxi/:id',
            templateUrl: 'templates/taxi/details.html',
            controller: 'TaxiCtrl'
        });


    $urlRouterProvider.otherwise('/bookings/new');
});
app.factory('Framework', function ($q) {
    var _navigator = $q.defer();
    var _cordova = $q.defer();

    if (window.cordova === undefined) {
        _navigator.resolve(window.navigator);
        _cordova.resolve(false);
    } else {
        document.addEventListener('deviceready', function (evt) {
            _navigator.resolve(navigator);
            _cordova.resolve(true);
        });
    }

    return {
        navigator: function() { return _navigator.promise; },
        cordova: function() { return _cordova.promise; }
    };
});