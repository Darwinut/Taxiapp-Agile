var module = angular.module('taksi_client');

module.service("config", [ function () {
    return {
        apiUrl: "http://guarded-castle-5410.herokuapp.com",
        pusherKey: '0707d6d9ef2c93628154'
    }
}]);