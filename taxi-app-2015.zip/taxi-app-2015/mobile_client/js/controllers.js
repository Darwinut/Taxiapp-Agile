var app = angular.module('taksi_client');

app.controller('BookingsCtrl', function($scope, $ionicModal, BookingsService, PusherService, LocationService, $timeout) {

    LocationService.init(10000);
    $scope.bookingRequest = {
        longitude: 0,
        latitude: 0,
        phone: "",
        name: "",
        address: ""
    };

    $scope.mapProp = {
        center: {lat: $scope.bookingRequest.latitude, lng: $scope.bookingRequest.longitude},
        zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    setTimeout(function () {
        $scope.map = new google.maps.Map(document.getElementById('map'), $scope.mapProp);
        $scope.marker = new google.maps.Marker({ map: $scope.map, position: $scope.mapProp.center});
    }, 100);


    $scope.sync = {
        syncNotification: '',
        asyncNotification: ''
    };

    $scope.submit = function() {
        BookingsService.save(angular.copy($scope.bookingRequest), function (response) {
                console.log(response);
                $scope.booking = response;
                $timeout(function() {
                    $scope.pollBooking();
                }, 10000);
                $scope.sync.syncNotification = response.message;
            }
        );
    };
    $scope.cancel = function () {
        if ($scope.booking) {
            $scope.sync.syncNotification = '';
            $scope.sync.asyncNotification = '';
            $scope.booking.taxi_id = null;
            $scope.booking.status = "finished";
            BookingsService.update(angular.copy($scope.booking), function (response) {
                $scope.booking = undefined;
            })
        }
    };

    $scope.onAsyncMessage = function(response) {
        console.log(response);
        $scope.sync.asyncNotification = response.message;
        $scope.sync.syncNotification = "";
    };

    $scope.getEstimate  = function () {
        return parseInt($scope.booking.delay_estimate/60).toString();
    };

    $scope.pollBooking = function () {
        if ($scope.booking && $scope.booking.id) {
            BookingsService.get({id: $scope.booking.id}, function (response) {
                $scope.booking = response;
                console.log($scope.booking);
                if ($scope.booking.status == "finished") {
                    $scope.sync.syncNotification = '';
                    $scope.sync.asyncNotification = '';
                    $scope.booking = undefined
                }
                $timeout(function() {
                    $scope.pollBooking();
                }, 10000);
            });
        } else {
            console.log("Wont poll");
        }
    };

    PusherService.onMessage($scope.onAsyncMessage);

    $scope.$on('location', function (event, position) {
        $scope.bookingRequest.latitude = position.coords.latitude;
        $scope.bookingRequest.longitude = position.coords.longitude;
        if ($scope.map) {
            $scope.marker.setPosition(new google.maps.LatLng(position.coords.latitude, position.coords.longitude));
            $scope.map.setCenter($scope.marker.getPosition());
        }
    });

});
