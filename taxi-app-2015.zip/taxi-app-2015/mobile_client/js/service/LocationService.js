var module = angular.module("taksi_client");

module.service("LocationService", ["Framework", "$rootScope", function (Framework, $rootScope) {
    return {
        initted : false,
        interval: 30000,
        intervalMethod: function () {
            var self = this;
            Framework.navigator().then(function (navigator) {
                console.log(self.interval);
                navigator.geolocation.getCurrentPosition(function(position) {
                    $rootScope.$broadcast("location", position);
                }, function (error) {
                    console.log(error);
                }, {timeout:self.interval/3, enableHighAccuracy: false });

            });
        },
        init: function (interval) {
            if (interval == undefined) {
                interval = 30000;
            }
            if (this.initted) return;
            this.interval = interval;
            var self = this;
            setInterval(function () {self.intervalMethod()}, interval);
            this.initted = true;
            this.intervalMethod();
        }
    }
}]);
