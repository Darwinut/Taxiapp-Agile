'use strict';

var app = angular.module('taksi_client');

app.service('PusherService', ["$rootScope", "config", function ($rootScope, config) {
  var pusher = new Pusher(config.pusherKey);
  var channel = pusher.subscribe('bookings');
  return {
    onMessage: function (callback) {
      channel.bind('async_notification', function (data) {

        $rootScope.$apply(function () {
          callback(data);
        });
      });
    },

    onCustomMessage: function (type, callback) {
        channel.bind(type, function (data) {
            $rootScope.$apply(function () {
                callback(data);
            });
        });
    },

    onBookingMessage: function (callback) {
      channel.bind("booking_request", function (data) {
          console.log(data);
          $rootScope.$apply(function () {
              callback(JSON.parse(data.message));
          });
      })
    }
  };
}]);