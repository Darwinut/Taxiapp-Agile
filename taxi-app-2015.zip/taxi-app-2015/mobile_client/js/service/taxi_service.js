'use strict';

var app = angular.module('taksi_client');

app.service('TaxiService', ['config', '$resource', function (config, $resource) {
    return $resource(config.apiUrl + '/taxis/:id', {id: "@id"},{
        'update': { method:'PUT' }
    });
}]);
