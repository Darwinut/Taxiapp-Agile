'use strict'

var app = angular.module('taksi_client');

app.controller('TaxiCtrl', ["$scope", "$stateParams", "TaxiService", "BookingsService","PusherService", "LocationService", "$interval", function ($scope, $routeParams, TaxiService, BookingsService, PusherService, LocationService, $interval) {
    LocationService.init();
    $scope.taxi = {
        latitude: 0,
        longitude: 0
    };
    $scope.lastServiceResponse = {};
    $scope.booking = undefined;
    $scope.mapProp = {
        center: {lat: $scope.taxi.latitude, lng: $scope.taxi.longitude},
        zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    $scope.map = new google.maps.Map(document.getElementById('map-taxi-details'), $scope.mapProp);
    $scope.marker = new google.maps.Marker({ map: $scope.map, position: $scope.mapProp.center});




    $scope.updateTaxi = function () {
        TaxiService.get({id: $routeParams.id}, function (response) {
            $scope.taxi = response;
            if ($scope.taxi.booking) {
                $scope.booking = angular.copy($scope.taxi.booking);
                delete $scope.taxi.booking;
            } else {
                $scope.booking = undefined
            }
            $scope.lastServiceResponse = angular.copy($scope.taxi);
            delete $scope.lastServiceResponse.status;
            console.log("######DEBUG########");
            console.log($scope.taxi);
            console.log($scope.booking);
            console.log("######DEBUG########");
        });
    };

    $interval(function () {
        $scope.updateTaxi();
    }, 10000);
    $scope.updateTaxi();

    $scope.update = function (data) {
        TaxiService.update(data, function (response) {
            $scope.taxi = response;
            $scope.lastServiceResponse = angular.copy(response);
        });
    };

    $scope.submit = function() {
        if ($scope.taxi.id) {
            $scope.update(angular.copy($scope.taxi));
        } else {
            TaxiService.save(angular.copy($scope.taxi), function (response) {
                console.log(response);
                $scope.taxi = response;
            })
        }
    };

    $scope.$on('location', function (event, data) {
        $scope.marker.setPosition(new google.maps.LatLng(data.coords.latitude, data.coords.longitude));
        $scope.map.setCenter($scope.marker.getPosition());
        if ($scope.lastServiceResponse.id == undefined) {
            return;
        }

        $scope.lastServiceResponse.latitude = data.coords.latitude;
        $scope.lastServiceResponse.longitude = data.coords.longitude;
        $scope.update(angular.copy($scope.lastServiceResponse));

    });

    $scope.accept = function () {
        $scope.booking.status = "in_progress";
        BookingsService.update({
            id: $scope.booking.id,
            status: $scope.booking.status
        }, function (response) {
            $scope.booking = response;
        });
    };

    $scope.decline = function () {
        $scope.booking.status = "declined";
        BookingsService.update({
            id: $scope.booking.id,
            status: $scope.booking.status
        }, function (response) {
            $scope.booking = undefined;
        });
    };

    $scope.takePassenger = function () {
        $scope.booking.status = "driving";
        BookingsService.update({
            id: $scope.booking.id,
            status: $scope.booking.status
        }, function (response) {
            console.log(response)
            $scope.booking = response;
        });
    };

    $scope.finishProcessing = function () {
        $scope.booking.status = "finished";
        BookingsService.update(angular.copy($scope.booking), function (response) {
            console.log(response);
        });
    };

    $scope.onBooking = function (booking) {
        $scope.booking = booking;
    };

    PusherService.onBookingMessage(function (booking) {
        if (booking.taxi_id == $scope.taxi.id) {
            $scope.onBooking(booking);
        }
    });
}]);

/**
 * Below this points is stuff.. that is not detail view.
 */

app.controller("CreateTaxiCtrl", ["$scope", "TaxiService" ,"$location", function ($scope, TaxiService, $location) {
    $scope.taxi = {
        latitude: 58.3782485,
        longitude: 26.7146733,
        status: "available"
    };

    $scope.mapProp = {
        center: {lat: $scope.taxi.latitude, lng: $scope.taxi.longitude},
        zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    setTimeout(function () {
        $scope.map = new google.maps.Map(document.getElementById('map-new-taxi'), $scope.mapProp);
        $scope.marker = new google.maps.Marker({ map: $scope.map, position: $scope.mapProp.center});
    }, 100);

    $scope.$on("location", function (event, position) {
        if ($scope.map) {
            $scope.marker.setPosition(new google.maps.LatLng(position.coords.latitude, position.coords.longitude));
            $scope.map.setCenter($scope.marker.getPosition());
        }
        $scope.taxi.latitude = position.coords.latitude;
        $scope.taxi.longitude = position.coords.longitude;
    });

    $scope.submit = function () {
        TaxiService.save(angular.copy($scope.taxi), function (response) {
            console.log(response);
            $location.path("taxi/" + response.id);
        });
    };
}]);

app.controller("TaxiListCtrl", ["$scope", "TaxiService", "LocationService", function ($scope, TaxiService, LocationService) {
    LocationService.init();
    $scope.list = [];

    $scope.onListResponse = function (taxis) {
        $scope.list = taxis;
    };
    TaxiService.query($scope.onListResponse);
}]);
