'use strict';

describe('BookingsCtrl', function () {

    beforeEach(angular.mock.module("taksi_client"));

  var BookingsCtrl,
    scope;

  beforeEach(inject(function ($controller, $rootScope, _$httpBackend_, _BookingsService_, _PusherService_) {
    scope = $rootScope.$new();
    BookingsCtrl = $controller('BookingsCtrl', {
        $scope: scope,
        BookingsService: _BookingsService_,
        PusherService: _PusherService_
    });
  }));

    var $httpBackend = {};
    var config = {};

    beforeEach(inject(function (_config_, _$httpBackend_) {
        $httpBackend = _$httpBackend_;
        config = _config_;
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('should be connected to its view', function () {
      expect(scope.latitude).toBeDefined();
      expect(scope.longitude).toBeDefined();
      expect(scope.submit).toBeDefined();
    });


    it('should submit a request to the backend service', function () {
        $httpBackend
            .expectPOST(config.apiUrl + '/bookings')
            .respond(201);
        scope.submit();
        $httpBackend.flush();
    });

    it('should submit a request to the backend service', function () {
        $httpBackend
            .expectPOST(config.apiUrl + '/bookings')
            .respond(201);
        scope.latitude = 58.37824850000001;
        scope.longitude = 26.7146733;
        scope.submit();
        $httpBackend.flush();
    });
});



