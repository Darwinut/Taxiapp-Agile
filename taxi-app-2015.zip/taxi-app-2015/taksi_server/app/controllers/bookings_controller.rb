class BookingsController < ApplicationController
  def create
    booking = BookingService.create(params)
    BookingService.assign_taxi(booking)
    #BookingService.send_confirmation_to_client(booking)

    response = model_params_from_hash(Booking, booking.attributes)
    response[:status] = :created

    if params[:address].nil? or params[:name].nil? or params[:phone].nil?
      response[:message] = "Booking is being processed"
    elsif not (params[:latitude].nil? or params[:longitude].nil?)
      response[:message] = "Booking is being processed"
    else
      response[:message] = "Booking is being processed"
    end

    render :json => response
  end
  
  def update
    booking = Booking.find(params[:id])
    if params[:status] == "declined"
      BookingService.assign_taxi(booking)
      params.delete(:status)
    else
      BookingService.update(booking, params)
    end

    render :json => booking
  end

  def index
    render :json => Booking.all
  end
  
  def show
    booking = Booking.find(params[:id])
    booking_json = booking.attributes.clone

    if booking.taxi_id.nil?
      BookingService.assign_taxi(booking)
      booking_json = booking.attributes.clone
    else
      if booking.status == 'pending'
        if (booking.assigned_at - DateTime.now).abs > 30
          BookingService.assign_taxi(booking)
          booking_json = booking.attributes.clone
        end
      end
    end

    if not booking.taxi_id.nil?
      if booking.status == 'pending' || booking.status == 'in_progress'
        booking_json['delay_estimate'] = BookingService.get_delay_estimate(booking)
      end
    end

    render :json => booking_json
  end

  def self.get_confirmation(booking)
    if !booking[:taxi_id]
      return { taxi: nil }
    end
    
    taxi = Taxi.find(booking[:taxi_id])

    # STRS will inform the customer of the time when the taxi will pick them up.
    delay_estimate = BookingService.get_delay_estimate(booking)
    
    { taxi: taxi, delay_estimate: delay_estimate }
  end
  
  def self.taxi_booking_request_callback(booking, response)
    # The taxi driver can accept the order or reject it.
    
    # If rejected, an alternative taxi is assigned by STRS.
    if response == :reject or response == :timeout
      # Ignore the current assigned taxi in the search
      new_taxi = TaxiService.find_closest_available_taxi(booking, [Taxi.find(booking[:taxi_id])])
      BookingService.update(booking, :taxi_id => new_taxi.id)
    end
  end
end