class InvoicesController < ApplicationController
	def index
		render :json => Taxi.all
	end

	def show
		bs = Booking.where(taxi_id: params[:id]).where(status: "finished")
		bs = bs.all.group_by {|b| b.created_at.beginning_of_month }
		res = []
		bs.each do |month, records|
			sum = 0
			records.each do |record|
				if not record.cost.nil?
					sum += record.cost
				end
			end
			res = res + [{month: month, sum: sum}]
		end
		render :json => res
	end
end
