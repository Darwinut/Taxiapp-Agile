class TaxisController < ApplicationController
  def create
    taxi = TaxiService.create(params)
    render :json => taxi
  end
  
  def update
    taxi = Taxi.find(params[:id])
    Geocoder.sync_address_and_coords(params)
    TaxiService.update(taxi, params)

    render :json => taxi
  end
  
  def index
    render :json => Taxi.all
  end
  
  def show
    taxi = Taxi.find(params[:id])
    bookings = Booking.where(:taxi_id => taxi.id).where.not(:status => "finished")

    taxi_json = taxi.attributes.clone
    if bookings.length == 1
      taxi_json['booking'] = bookings[0].attributes
    else bookings.length > 1
      bookings.each do |booking|
        BookingService.update(booking, :status => "finished")
      end
    end
    render :json => taxi_json
  end
end