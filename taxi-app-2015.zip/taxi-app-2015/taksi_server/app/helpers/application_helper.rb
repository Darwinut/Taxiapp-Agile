module ApplicationHelper
    def mock_locate(address, mockfilename)
        body = File.read(mockfilename)
        stub_request(:get, "http://maps.googleapis.com/maps/api/geocode/json?address=#{address}&sensor=false").
            with(:headers => {'Accept'=>'*/*', 'Accept-Encoding'=>'gzip;q=1.0,deflate;q=0.6,identity;q=0.3', 'Host'=>'maps.googleapis.com', 'User-Agent'=>'Ruby'}).
            to_return(:status => 200, :body => body, :headers => {})
    end

    def mock_distance(destinations, origins, mockfilename)
        body = File.read(mockfilename)
        stub_request(:get, "https://maps.googleapis.com/maps/api/distancematrix/json?destinations=#{destinations}&origins=#{origins}").
            with(:headers => {'Accept'=>'*/*', 'Accept-Encoding'=>'gzip;q=1.0,deflate;q=0.6,identity;q=0.3', 'Host'=>'maps.googleapis.com', 'User-Agent'=>'Ruby'}).
            to_return(:status => 200, :body => body, :headers => {})
    end

    def mock_geocoder
        mock_locate("Liivi%202,%20Tartu,%20Estonia", "spec/liivi2.json")
        mock_locate("Tartu%20Kaubamaja", "spec/kaubamaja.json")
        mock_locate("Tartu%20Lounakeskus", "spec/lounakeskus.json")
        mock_locate("58.3782485,26.7146733", "spec/liivi2_reverse.json")
        mock_locate("58.37763099999999,26.727978", "spec/kaubamaja_by_coords.json")

        mock_distance("Tartu%20Kaubamaja", "Juhan%20Liivi%202,%2050409%20Tartu,%20Eesti", "spec/liivi2_kaubamaja.json")
        mock_distance("Tartu%20Kaubamaja", "Liivi 2,%20Tartu,%20Estonia", "spec/liivi2_kaubamaja.json")
        mock_distance("Tartu%20Lounakeskus", "Juhan%20Liivi%202,%2050409%20Tartu,%20Eesti", "spec/liivi2_lounakeskus.json")
        mock_distance("Tartu%20Lounakeskus", "Liivi%202,%20Tartu,%20Estonia", "spec/liivi2_lounakeskus.json")
    end
    
    def model_params_from_hash(class_, params)
        new_params = {}
        model_fields = class_.columns_hash.keys
        params.each do |param, value|
            if model_fields.include?(param.to_s)
                new_params[param] = params[param]
            end
        end
        new_params
    end
end
