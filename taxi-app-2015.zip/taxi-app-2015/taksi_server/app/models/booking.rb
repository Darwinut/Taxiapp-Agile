class Booking < ActiveRecord::Base

  # pending - waiting for a taxi to be assigned
  # in_progress - taxi has been assigned
  # driving - taxi picked up the client
  # finished - taxi dropped off the client

  def self.all_statuses
    ["pending", "in_progress", "driving", "finished"]
  end

  validates :status, inclusion: { in: all_statuses,
    message: "%{value} is not a valid size" }

  before_create do |booking|
    booking.created_at = DateTime.now
  end
end