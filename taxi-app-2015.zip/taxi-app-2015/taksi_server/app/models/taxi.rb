class Taxi < ActiveRecord::Base
    def self.all_statuses
        ["available", "busy", "invisible", "off_duty"]
    end

    validates :status, inclusion: { in: all_statuses,
        message: "%{value} is not a valid size" }

    before_create do |taxi|
        taxi.status_changed = DateTime.now
    end
end