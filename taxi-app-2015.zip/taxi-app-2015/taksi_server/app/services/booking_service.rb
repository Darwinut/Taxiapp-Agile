include ApplicationHelper

class BookingService
    def self.create(params)
        # Prefer the user-specified address over coordinates
        if params.include?(:address) and params[:address].length > 0
            res = Geocoder.locate(params[:address])
            params[:latitude] = res[:latitude]
            params[:longitude] = res[:longitude]
        else
            Geocoder.sync_address_and_coords(params)
        end

        params['status'] ||= 'pending'

        Booking.create!(model_params_from_hash(Booking, params))
    end

    # Returns expected delay in seconds
    def self.get_delay_estimate(booking)
        taxi = Taxi.find(booking.taxi_id)

        # STRS will inform the customer of the time when the taxi will pick them up.
        delay_estimate = Geocoder.distance_and_duration_by_locinfo(booking.attributes, taxi.attributes)[0]["duration"]["value"]
        if booking.status == "pending"
            delay_estimate += 30 # extra time for taxi driver to confirm
        end
        return delay_estimate
    end
 
    def self.update(booking, params)
        Geocoder.sync_address_and_coords(params)

        if params.include?(:status) && params[:status] == "finished"
            if booking.status != "finished"
                taxi = Taxi.find(booking.taxi_id)
                TaxiService.update(taxi, :status => "available")
                if params.include?(:taxi_id) && params[:taxi_id].nil?
                else
                    distance = Geocoder.distance_and_duration_by_locinfo(booking.attributes, taxi.attributes)[0]["distance"]["value"]
                    cost = 2 + (distance * 0.001) * 0.4
                    params[:cost] = cost
                end
            end
        end

        booking.update!(model_params_from_hash(Booking, params))
        booking.reload
    end
 
    def self.assign_taxi(booking)
        # When STRS receives a new taxi order, it assigns it to the closest available taxi.
        if booking.taxi_id != nil
            rejected_taxi = Taxi.find(booking.taxi_id)
            taxi = TaxiService.find_closest_available_taxi(booking, [rejected_taxi])
            if taxi
                TaxiService.update(rejected_taxi, :status => "available")
            end
        else
            taxi = TaxiService.find_closest_available_taxi(booking)
        end
        if taxi
            TaxiService.update(taxi, :status => "busy")
            BookingService.update(booking, {:taxi_id => taxi.id, :assigned_at => DateTime.now})
        else
            BookingService.update(booking, :status => "pending")
        end
        
        Pusher.trigger('bookings', 'booking_request', {
            message: booking.to_json
        })
    end
    
    def self.send_confirmation_to_client(booking)
        confirmation = BookingsController.get_confirmation(booking)
        if confirmation.include?(:delay_estimate)
            delay_estimate_minutes = (confirmation[:delay_estimate] / 60).to_s
            delay_estimate_text = "Estimated time of arrival: #{delay_estimate_minutes} minutes."
        else
            delay_estimate_text = "No taxi available!"
        end

        Pusher.trigger('bookings', 'async_notification', {
            message: "Your Location: " + booking.address + '; ' +
              delay_estimate_text
        })
    end
end