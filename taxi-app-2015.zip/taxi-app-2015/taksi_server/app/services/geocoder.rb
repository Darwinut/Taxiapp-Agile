require 'net/http'

class Geocoder
    def self.locate(address)
        addressEncoded = URI.escape(address)
        uri = URI("http://maps.googleapis.com/maps/api/geocode/json?address=#{addressEncoded}&sensor=false")
        response = Net::HTTP.get(uri)
        json = ActiveSupport::JSON.decode(response)
        
        location = json["results"][0]["geometry"]["location"]
        {latitude: location["lat"], longitude: location["lng"]}
    end
    
    def self.address_by_coords(lat, lng)
        coords = lat.to_s + ',' + lng.to_s
        uri = URI("http://maps.googleapis.com/maps/api/geocode/json?address=#{coords}&sensor=false")
        response = Net::HTTP.get(uri)
        json = ActiveSupport::JSON.decode(response)
        
        json['results'][0]['formatted_address']
    end

    # locinfo is a hash of {latitude, longitude, address}
    def self.distance_and_duration_by_locinfo(locinfo1, locinfo2)
        if locinfo1.include?("address") && locinfo2.include?("address")
            if (not locinfo1["address"].nil?) && (not locinfo2["address"].nil?)
                locations = self.distance_and_duration_by_address(locinfo1["address"], locinfo2["address"])
                if locations.length > 0
                    return locations
                end
            end
        end

        # Service found no route, return straight distance
        distance = Math.sqrt(((locinfo1["latitude"] - locinfo2["latitude"]) ** 2) + ((locinfo1["longitude"] - locinfo2["longitude"]) ** 2))
        distance *= 110 # 1 degree = ~ 110 km
        duration = (distance / 1000.0) / 50.0 # 50 km / h
        duration *= 3600 # hours to seconds
        return [{"distance" => {"value" => distance}, "duration" => {"value" => duration}}]
    end
    
    def self.distance_and_duration_by_address(address1, address2)
        addressEncoded1 = URI.escape(address1)
        addressEncoded2 = URI.escape(address2)
        uri = URI("https://maps.googleapis.com/maps/api/distancematrix/json?destinations=#{addressEncoded2}&&origins=#{addressEncoded1}")
        response = Net::HTTP.get(uri)
        json = ActiveSupport::JSON.decode(response)
        json["rows"][0]["elements"]
    end

    def self.sync_address_and_coords(args)
        if args[:latitude].nil? and args[:longitude].nil?
            # There may be no location info in update requests,
            # in that case, do nothing.
            if args[:address].nil?
                return args
            end
            res = locate(args[:address])
            args[:latitude] = res[:latitude]
            args[:longitude] = res[:longitude]
        else
            res = address_by_coords(args[:latitude], args[:longitude])
            args[:address] = res
        end
        
        args
    end
end
