include ApplicationHelper

class TaxiService
  def self.create(params)
    Geocoder.sync_address_and_coords(params)
    params['status'] ||= 'available'

    Taxi.create(model_params_from_hash(Taxi, params))
  end

  def self.update(taxi, params)
    if params.include?(:status)
      if params[:status] != taxi.status
        params[:status_changed] = DateTime.now
      end
    else
      params.delete(:status_changed)
    end

    taxi.update(model_params_from_hash(Taxi, params))
    taxi.reload
  end
  
  def self.find_closest_available_taxi(booking, taxis_ignored = [])
    taxi_closest = nil
    distance_closest = Float::MAX
    Taxi.where(:status => "available").each do |taxi|
      if taxis_ignored.include?(taxi)
        next
      end

      distance = Geocoder.distance_and_duration_by_locinfo(booking.attributes, taxi.attributes)[0]["distance"]["value"]

      # If there are several taxis at equal or almost equal distance from the location,
      # the taxi that has been available the longest is assigned (i.e. first-in-first-out).
      epsilon = 30
      if (distance - distance_closest).abs < epsilon
        if taxi[:status_changed] < taxi_closest[:status_changed]
          distance_closest = distance
          taxi_closest = taxi
        end
      elsif distance < distance_closest
        distance_closest = distance
        taxi_closest = taxi
      end
    end
    return taxi_closest
  end
end
