require 'pusher'

Pusher.url = "https://0707d6d9ef2c93628154:132ac84f4e8d592d9973@api.pusherapp.com/apps/156109"
Pusher.logger = Rails.logger
