class CreateTables < ActiveRecord::Migration
  def up
    create_table :bookings do |t|
        t.string :status
        t.string :address
    end

    create_table :taxis do |t|
        t.string :address
        t.string :status
        t.datetime :status_changed
    end
  end
  
  def down
    drop_table :movies
  end
end
