class BookingHasTaxi < ActiveRecord::Migration
  def change
    add_reference :bookings, :taxi
  end
end
