class AddLatitudeAndLongitudeToTaxi < ActiveRecord::Migration
  def change
    add_column :taxis, :latitude, :float
    add_column :taxis, :longitude, :float
  end
end
