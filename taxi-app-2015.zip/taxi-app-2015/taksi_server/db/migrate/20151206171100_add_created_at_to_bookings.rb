class AddCreatedAtToBookings < ActiveRecord::Migration
  def change
    add_column :bookings, :created_at, :datetime
  end
end
