class AddAssignedTimeToBookings < ActiveRecord::Migration
  def change
    add_column :bookings, :assigned_at, :datetime
  end
end
