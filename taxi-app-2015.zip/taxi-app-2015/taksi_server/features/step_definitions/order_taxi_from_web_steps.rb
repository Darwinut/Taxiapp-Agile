Given(/^I am visiting the web interface$/) do
  visit "http://localhost:8080/#/bookings"
  #@booking_params = {}
end

Given /there are two taxis available, one next to (.*) and the other at (.*)/ do |loc1, loc2|
  TaxiService.create!(:address => loc1)
  TaxiService.create!(:address => loc2)
end

When(/^I set my address as "(.*)"$/) do |address|
  #@booking_params[:address] = address
  fill_in 'address-input', with: address
end

When(/^I set my name as "(.*)"$/) do |name|
  #@booking_params[:name] = name
  fill_in 'name-input', with: name
end

When(/^I set my phone as "(.*)"$/) do |phone|
  #@booking_params[:phone] = phone
  fill_in 'phone-input', with: phone
end

When(/^I submit my booking request$/) do
  #@booking = BookingService.create(@booking_params)
  #BookingService.assign_taxi(@booking)
  mock_geocoder

  click_button 'submit-coord'
  #visit "http://asd-anthrax11.c9users.io:8081/bookings"
  page.save_screenshot("screen.png")
end

Then(/^I should receive the time of arrival as (.*) minutes from now$/) do |qty|
  #delay = BookingService.get_delay_estimate(@booking)
  #expect(delay).to be_within(60).of(qty.to_i * 60)
  sleep 2.seconds
  puts Booking.all.inspect
  expect(page).to have_content("ETA: #{qty} minutes")
end