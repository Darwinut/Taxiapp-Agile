Given(/^I am in the booking page$/) do
  visit "http://localhost:8080/#/bookings"
  #@booking_params = {}
end

When(/^I provide my coordinates$/) do
  fill_in 'lat-input', with: '58.3782485'
  fill_in 'lng-input', with: '26.7146733'
  #@booking_params[:latitude] = 58.3782485
  #@booking_params[:longitude] = 26.7146733
end

When(/^I submit this information$/) do
  click_button 'submit-coord'
  #mock_geocoder
  #@booking = BookingService.create(@booking_params)
end

Then(/^I should be notified that my information is being processed$/) do
  expect(page).to have_content("Booking is being processed")
  #expect(@booking.status).to eq "pending"
end

Then(/^I should eventually receive an asynchronous message with my address$/) do
  sleep 1.seconds
  expect(page).to have_content("Juhan Liivi 2, 50409 Tartu, Estonia")
  #expect(@booking.address).to eq "Juhan Liivi 2, 50409 Tartu, Eesti"
end
