When(/^I sign in to STRS$/) do
  @taxi = TaxiService.create(:address => @loc)
end

When(/^I set my status to busy/) do
  @taxi.update(:status => "busy")
end

Then(/^I should be busy/) do
  @taxi.reload
  expect(@taxi.status).to eq 'busy'
end
