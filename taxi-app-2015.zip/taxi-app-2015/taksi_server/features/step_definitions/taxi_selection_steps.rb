Given /I am at (.*)/ do |loc|
    @loc = loc
    mock_geocoder # in ApplicationHelper
end

Given /there are two taxi available, at the same distance with respect to (.*)/ do |loc|
    # Have the taxis be at the same location
    loc2 = "Tartu Kaubamaja"
    @taxi1 = TaxiService.create(:address => loc2)
    @taxi2 = TaxiService.create(:address => loc2)
    
    # Taxi 2 has been available for longer
    TaxiService.update(@taxi2, :status_changed => (@taxi2.status_changed - 14.minutes))
end

Given /there are two taxi available, one next to (.*) and the other at (.*)/ do |loc_closer, loc_farther|
    mock_geocoder
    @taxi1 = TaxiService.create(:address => loc_closer)
    @taxi2 = TaxiService.create(:address => loc_farther)
end

When /I submit a booking request/ do
    @booking = BookingService.create(:address => @loc)
    BookingService.assign_taxi(@booking)
end

When /STRS sends the booking request to the closest taxi/ do
    BookingService.send_confirmation_to_client(@booking)
end

When /The taxi driver accepts the booking/ do
    BookingsController.taxi_booking_request_callback(@booking, :accept)
end

When /The taxi driver of the closest taxi rejects the booking/ do
    BookingsController.taxi_booking_request_callback(@booking, :reject)
end

When /The taxi driver does not reply before 30 seconds/ do
    BookingsController.taxi_booking_request_callback(@booking, :timeout)
end

Then /I should receive a confirmation with the taxi next to (.*)/ do |loc|
    @confirmation = BookingsController.get_confirmation(@booking)
    expect(@confirmation[:taxi].address).to eq loc
end

Then /I should receive a confirmation with the taxi that has been available the longest/ do
    @confirmation = BookingsController.get_confirmation(@booking)
    expect(@confirmation[:taxi].id).to be @taxi2.id
end

Then /I should receive a delay estimate/ do
    expect(@confirmation[:delay_estimate]).to_not be_nil
end

Then /I should receive a confirmation with the information of the closest taxi/ do
    @confirmation = BookingsController.get_confirmation(@booking)
    expect(@confirmation[:taxi].id).to be @taxi1.id
end

Then /STRS should be resent to the other taxi/ do
    expect(@booking.taxi_id).to be @taxi2.id
end

Then /STRS should select another taxi/ do
    step %{STRS should be resent to the other taxi}
end
