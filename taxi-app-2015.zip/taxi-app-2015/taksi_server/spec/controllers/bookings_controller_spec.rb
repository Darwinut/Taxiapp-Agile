require 'rails_helper'

describe BookingsController do
  context 'Create booking' do
    it 'receives confirmation with an available taxi' do
        mock_geocoder

        taxi = TaxiService.create(:address => "Tartu Kaubamaja")
        post :create, address: "Liivi 2, Tartu, Estonia"
        booking_json = JSON.parse(@response.body)
        booking = Booking.find(booking_json['id'])
        BookingService.assign_taxi(booking)
        BookingService.send_confirmation_to_client(booking)

        confirmation = BookingsController.get_confirmation(booking)
        expect(confirmation[:taxi][:address]).to eq taxi[:address]

        get :index
        bookings = JSON.parse(@response.body)
        expect(bookings.length).to be 1

        get :show, {:id => booking.id}
        booking_show = JSON.parse(@response.body)
        expect(booking_show['id']).to be booking.id
    end
    
    it 'receives confirmation with the closest available taxi' do
        mock_geocoder

        taxi_further = TaxiService.create(:address => "Tartu Lounakeskus")
        taxi_closer = TaxiService.create(:address => "Tartu Kaubamaja")
        post :create, address: "Liivi 2, Tartu, Estonia"
        booking_json = JSON.parse(@response.body)
        booking = Booking.find(booking_json['id'])

        confirmation = BookingsController.get_confirmation(booking)
        expect(confirmation[:taxi][:address]).to eq taxi_closer[:address]
    end

    it 'receives confirmation with the closest available taxi that was available for longer' do
        mock_geocoder

        taxi1 = TaxiService.create(:address => "Tartu Lounakeskus")
        taxi2 = TaxiService.create(:address => "Tartu Lounakeskus")
        post :create, address: "Liivi 2, Tartu, Estonia"
        booking_json = JSON.parse(@response.body)
        booking = Booking.find(booking_json['id'])

        confirmation = BookingsController.get_confirmation(booking)
        expect(confirmation[:taxi][:address]).to eq taxi2[:address]
    end

    it 'assigns another taxi if a request is declined' do
        mock_geocoder

        taxi_further = TaxiService.create(:address => "Tartu Lounakeskus")
        taxi_closer = TaxiService.create(:address => "Tartu Kaubamaja")

        post :create, address: "Liivi 2, Tartu, Estonia"
        booking_json = JSON.parse(@response.body)
        booking = Booking.find(booking_json['id'])

        post :update, {:id => booking.id, :status => "declined"}
        booking.reload

        confirmation = BookingsController.get_confirmation(booking)
        expect(confirmation[:taxi][:address]).to eq taxi_further[:address]
    end
  end
end