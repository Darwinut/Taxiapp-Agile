require 'rails_helper'

describe InvoicesController do
  context 'Invoice calculation' do
    it 'returns empty array with no taxis' do
      get :index
      expect(response.body).to eq "[]"
    end

    it 'calculates invoice for two bookings in a month' do
      mock_geocoder

      taxi = TaxiService.create(:address => "Tartu Kaubamaja")

      booking = BookingService.create(:address => "Liivi 2, Tartu, Estonia")
      BookingService.assign_taxi(booking)
      BookingService.update(booking, :status => "finished")

      booking = BookingService.create(:address => "Liivi 2, Tartu, Estonia")
      BookingService.assign_taxi(booking)
      BookingService.update(booking, :status => "finished")

      get :show, {:id => taxi.id}
      invoices = JSON.parse(@response.body)
      expect(invoices.length).to be 1
      expect(invoices[0]['sum']).to be_within(0.01).of 5.7
    end
  end
end