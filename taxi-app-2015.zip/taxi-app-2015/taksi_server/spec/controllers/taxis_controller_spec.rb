require 'rails_helper'

describe TaxisController do
  context 'Create taxi' do
    it 'creates an instance of a taxi' do
      mock_geocoder
      expect{
        post :create, address: "Tartu Kaubamaja"
      }.to change(Taxi, :count).by(1)

      get :index
      taxis = JSON.parse(@response.body)
      expect(taxis.length).to be 1

      taxi = taxis[0]
      expect(taxi['address']).to eq "Tartu Kaubamaja"

      get :show, id: taxi['id']
      taxi_show = JSON.parse(@response.body)
      expect(taxi_show['id']).to be taxi['id']
      expect(taxi_show['address']).to eq "Tartu Kaubamaja"
    end
    
    it 'responds with the information of the new taxi' do
      mock_geocoder
      post :create, address: "Tartu Kaubamaja"
      taxi = JSON.parse(@response.body)
      expect(taxi["address"]).to eq("Tartu Kaubamaja") 
    end
    
    it 'changes taxi status to available' do
      mock_geocoder
      post :create, address: "Tartu Kaubamaja"
      taxi = JSON.parse(@response.body)
      expect(taxi["status"]).to eq("available") 
    end
  end
  
  context 'Updating a taxi' do
    it 'responds with the updated information' do
      mock_geocoder
      
      post :create, address: "Tartu Kaubamaja"
      id = JSON.parse(@response.body)["id"]
      
      post :update, {:status => "busy", :id => id, :address => "Tartu Kaubamaja"}
      
      taxi = Taxi.find(id)
      expect(taxi.status).to eq("busy")
    end
    
    it 'changes status to busy' do
      mock_geocoder
      
      post :create, address: "Tartu Kaubamaja"
      id = JSON.parse(@response.body)["id"]
      status_changed = JSON.parse(@response.body)["status_changed"]

      post :update, {id: id, status: "busy"}
      
      new_status_changed = JSON.parse(@response.body)["status_changed"]
      expect(new_status_changed).not_to eq(status_changed)
    end
    
    it 'synchronizes the address and coordinates' do
      mock_geocoder
      
      post :create, address: "Liivi 2, Tartu, Estonia"
      id = JSON.parse(@response.body)["id"]
      
      post :update, {id: id, latitude: 58.37763099999999, longitude: 26.727978}
      
      new_address = JSON.parse(@response.body)["address"]
      expect(new_address).to eq("Riia 1, 51004 Tartu, Eesti")
    end
  end
end