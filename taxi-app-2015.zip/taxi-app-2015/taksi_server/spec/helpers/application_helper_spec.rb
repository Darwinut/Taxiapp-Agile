require 'rails_helper'

describe ApplicationHelper do
    context 'Extract parameters' do
        it 'Extracts parameters that exist in the model' do
            params = model_params_from_hash(Taxi, {:address => "Tartu", :somethingelse => "Blabla"})
            expect(params.length).to be(1)
            expect(params[:address]).to eq("Tartu")
        end
    end
end