require 'rails_helper'

describe 'Booking service' do
    it 'creates booking' do
        mock_geocoder
        
        params = { :latitude => 58.3782485, :longitude => 26.7146733, :name => "Erich", :phone => "555-5555"}
        booking = BookingService.create(params)
        expect(booking).to_not be_nil
        expect(booking[:address]).to eq("Juhan Liivi 2, 50409 Tartu, Eesti")
        expect(booking[:name]).to eq(params[:name])
        expect(booking[:phone]).to eq(params[:phone])
    end
    
    it 'finds the closest available taxi' do
        mock_geocoder

        taxi = TaxiService.create(:address => "Tartu Kaubamaja")
        taxi2 = TaxiService.create(:address => "Tartu Lounakeskus")
        params = { :latitude => 58.3782485, :longitude => 26.7146733, :name => "Erich", :phone => "555-5555"}
        booking = BookingService.create(params)
        taxi_closest = TaxiService.find_closest_available_taxi(booking)
        expect(taxi_closest.id).to be(taxi.id)
    end
end
