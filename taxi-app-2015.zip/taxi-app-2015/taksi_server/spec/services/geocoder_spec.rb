require 'rails_helper'

describe 'External service' do
    it 'queries Google Maps web service for coordinates based on location' do
        mock_geocoder # in ApplicationHelper

        response = Geocoder.locate("Liivi 2, Tartu, Estonia")
        expect(response).to include(latitude: be_within(0.5).of(58.3), longitude: be_within(0.5).of(26.7))
        
        response = Geocoder.locate("Tartu Kaubamaja")
        expect(response).to include(latitude: be_within(0.5).of(58.3), longitude: be_within(0.5).of(26.7))
        
        response = Geocoder.locate("Tartu Lounakeskus")
        expect(response).to include(latitude: be_within(0.5).of(58.3), longitude: be_within(0.5).of(26.6))
    end
    it 'queries Google Maps Web service for location based on coordinates' do
        mock_geocoder
        
        response = Geocoder.address_by_coords(58.3782485, 26.7146733)
        expect(response).to eq("Juhan Liivi 2, 50409 Tartu, Eesti")
    end
    it 'queries Google Maps web service for distance and duration based on 2 locations' do
        mock_geocoder

        response = Geocoder.distance_and_duration_by_address("Liivi 2, Tartu, Estonia", "Tartu Lounakeskus")
        first = response[0]
        expect(first["distance"]["value"].to_i).to be_within(500).of(4148)
        expect(first["duration"]["value"].to_i).to be_within(298).of(526)
    end
end
